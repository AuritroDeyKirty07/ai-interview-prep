import axios from "axios";


const api = axios.create({
    baseURL:"http://localhost:3000",
    withCredentials:true
})

export async function register({ username, email, password }) {
  try {
    const response = await api.post(
      "/api/auth/register",
      {
        username,
        email,
        password,
      }
    );

    return response.data;
  } catch (err) {
    console.error(
      "register API error:",
      err.response?.data || err.message
    );
    throw err;
  }
}


export async function login({email, password}) {
    try {
        const response = await api.post("/api/auth/login", {
            email, password
        })
        return response.data;
    } catch (error) {
        console.error(
      "login API error:",
      error.response?.data || error.message
    );
    throw error;
  }
}

export async function logout() {
    try {
        const response = await api.get("/api/auth/logout")
        return response.data
    } catch (error) {
        console.error(
      "logout API error:",
      error.response?.data || error.message
    );
    throw error;
  }
}

export async function getMe() {
  const response = await api.get("/api/auth/get-me");
  return response.data;
}